#include "server.h"
#include "ui_server.h"
#include <QMessageBox>
#include <QString>
#include <QMessageBox>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>
#include <QDebug>

server::server(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::server)
{
    tcpsvr=new QTcpServer(this);
    socket =new QTcpSocket(this);
    ui->setupUi(this);
    db=QSqlDatabase::addDatabase("QSQLITE");
    db.setHostName("localhost");   //数据库服务器ip
    db.setUserName("root");        //数据库用户名
    db.setPassword("123456");      //密码
    db.setDatabaseName("info");    //使用哪个数据库
    if(!db.open())
    {
        QMessageBox::warning(this, "错误", db.lastError().text());
        return;
    }
    QSqlQuery query;
    query.prepare("CREATE TABLE usr(name varchar,password varchar)");
    query.exec();
    this->connect(ui->cnctbtn,SIGNAL(clicked()),this,SLOT(init()));
    this->connect(ui->sendbtn,SIGNAL(clicked()),this,SLOT(send(QString,QString)));
    db.close();
}

server::~server()
{
    delete ui;
}

void server::init()
{

    if(tcpsvr->listen(QHostAddress::Any,6666))
    {
        this->connect(tcpsvr,SIGNAL(newConnection()),this,SLOT(newconnect()));
    }
}


void server::newconnect()
{
    //QMessageBox::information(NULL, "连接成功", "连接成功！！！", QMessageBox::Yes);
    socket = tcpsvr->nextPendingConnection();
    this->connect(socket,SIGNAL(readyRead()),this,SLOT(read()));
}

void server::read()
{
    QString data = socket->readAll();
    qDebug()<<"接收成功";
    int lc=data.indexOf(",");
    user=data.mid(1,lc-1);
    pswd=data.mid(lc+1);
    if(data.left(1)=="1")//客户端传来数据为1开头则为注册
    {
        qDebug()<<user<<pswd;
        send(user,pswd);
    }
    else
    {
        qDebug()<<pswd<<user;
        regis(user,pswd);
    }
}

void server::send(QString user,QString pswd)
{
    if(judge(user,pswd))//登录成功返回1
    {
        this->socket->write("1");
        qDebug()<<1;
    }
    else
    {
        this->socket->write("0");//失败返回0
        qDebug()<<0;
    }
}

bool server::judge(QString user, QString pswd)
{
    /*QSqlDatabase db=QSqlDatabase::addDatabase("QSQLITE");
    db.setHostName("localhost");   //数据库服务器ip
    db.setUserName("root");        //数据库用户名
    db.setPassword("123456");      //密码
    db.setDatabaseName("info");    //使用哪个数据库*/
    qDebug()<<"进入judge";
    QSqlQuery query(db);
    QString str=QString("select * from usr where name='%1' and password='%2'").arg(user).arg(pswd);
    query.exec(str);
    if(query.first()) return true;
    return false;
}

void server::regis(QString us, QString ps)
{
    /*QSqlDatabase db=QSqlDatabase::addDatabase("QSQLITE");
    db.setHostName("localhost");   //数据库服务器ip
    db.setUserName("root");        //数据库用户名
    db.setPassword("123456");      //密码
    db.setDatabaseName("info");    //使用哪个数据库*/
    QSqlQuery query;
    QString str = QString("insert into usr(name, password) values('%1', '%2')").arg(us).arg(ps);
    //QMessageBox::information(NULL, "注册成功", "注册成功！！！", QMessageBox::Yes);
    query.exec(str);
}
