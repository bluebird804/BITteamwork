/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLabel *label;
    QFrame *frame;
    QTreeWidget *treeWidget;
    QToolButton *toolButton1_1;
    QToolButton *toolButton1_2;
    QToolButton *toolButton1_3;
    QToolButton *toolButton1_4;
    QToolButton *toolButton1_5;
    QToolButton *toolButton1_6;
    QToolButton *toolButton1_7;
    QPushButton *pushButton;
    QToolButton *chatroom;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(351, 737);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(100, 0, 201, 101));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(50);
        sizePolicy.setVerticalStretch(50);
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        QFont font;
        font.setPointSize(30);
        font.setBold(true);
        font.setItalic(true);
        font.setUnderline(false);
        font.setWeight(75);
        font.setStrikeOut(false);
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0, cy:0, angle:135, stop:0 rgba(255, 255, 0, 69), stop:0.375 rgba(255, 255, 0, 69), stop:0.423533 rgba(251, 255, 0, 145), stop:0.45 rgba(247, 255, 0, 208), stop:0.477581 rgba(255, 244, 71, 130), stop:0.518717 rgba(255, 218, 71, 130), stop:0.55 rgba(255, 255, 0, 255), stop:0.57754 rgba(255, 203, 0, 130), stop:0.625 rgba(255, 255, 0, 69), stop:1 rgba(255, 255, 0, 69));"));
        label->setFrameShape(QFrame::NoFrame);
        label->setMidLineWidth(0);
        label->setAlignment(Qt::AlignCenter);
        frame = new QFrame(centralWidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(-1, -1, 100, 100));
        sizePolicy.setHeightForWidth(frame->sizePolicy().hasHeightForWidth());
        frame->setSizePolicy(sizePolicy);
        frame->setStyleSheet(QString::fromUtf8("image: url(:/timg.jpg);"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        treeWidget = new QTreeWidget(centralWidget);
        QFont font1;
        font1.setPointSize(16);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem();
        __qtreewidgetitem->setFont(0, font1);
        treeWidget->setHeaderItem(__qtreewidgetitem);
        treeWidget->setObjectName(QString::fromUtf8("treeWidget"));
        treeWidget->setGeometry(QRect(0, 100, 351, 551));
        sizePolicy.setHeightForWidth(treeWidget->sizePolicy().hasHeightForWidth());
        treeWidget->setSizePolicy(sizePolicy);
        QFont font2;
        font2.setItalic(true);
        treeWidget->setFont(font2);
        toolButton1_1 = new QToolButton(centralWidget);
        toolButton1_1->setObjectName(QString::fromUtf8("toolButton1_1"));
        toolButton1_1->setGeometry(QRect(0, 130, 351, 71));
        sizePolicy.setHeightForWidth(toolButton1_1->sizePolicy().hasHeightForWidth());
        toolButton1_1->setSizePolicy(sizePolicy);
        QFont font3;
        font3.setFamily(QString::fromUtf8("Ubuntu"));
        font3.setPointSize(20);
        font3.setBold(false);
        font3.setItalic(true);
        font3.setWeight(50);
        font3.setKerning(true);
        toolButton1_1->setFont(font3);
        toolButton1_1->setStyleSheet(QString::fromUtf8(""));
        toolButton1_1->setIconSize(QSize(16, 16));
        toolButton1_2 = new QToolButton(centralWidget);
        toolButton1_2->setObjectName(QString::fromUtf8("toolButton1_2"));
        toolButton1_2->setGeometry(QRect(0, 200, 351, 71));
        sizePolicy.setHeightForWidth(toolButton1_2->sizePolicy().hasHeightForWidth());
        toolButton1_2->setSizePolicy(sizePolicy);
        toolButton1_2->setFont(font3);
        toolButton1_2->setStyleSheet(QString::fromUtf8(""));
        toolButton1_2->setIconSize(QSize(16, 16));
        toolButton1_3 = new QToolButton(centralWidget);
        toolButton1_3->setObjectName(QString::fromUtf8("toolButton1_3"));
        toolButton1_3->setGeometry(QRect(0, 270, 351, 71));
        sizePolicy.setHeightForWidth(toolButton1_3->sizePolicy().hasHeightForWidth());
        toolButton1_3->setSizePolicy(sizePolicy);
        toolButton1_3->setFont(font3);
        toolButton1_3->setStyleSheet(QString::fromUtf8(""));
        toolButton1_3->setIconSize(QSize(16, 16));
        toolButton1_4 = new QToolButton(centralWidget);
        toolButton1_4->setObjectName(QString::fromUtf8("toolButton1_4"));
        toolButton1_4->setGeometry(QRect(0, 340, 351, 71));
        sizePolicy.setHeightForWidth(toolButton1_4->sizePolicy().hasHeightForWidth());
        toolButton1_4->setSizePolicy(sizePolicy);
        toolButton1_4->setFont(font3);
        toolButton1_4->setStyleSheet(QString::fromUtf8(""));
        toolButton1_4->setIconSize(QSize(16, 16));
        toolButton1_5 = new QToolButton(centralWidget);
        toolButton1_5->setObjectName(QString::fromUtf8("toolButton1_5"));
        toolButton1_5->setGeometry(QRect(0, 410, 351, 71));
        sizePolicy.setHeightForWidth(toolButton1_5->sizePolicy().hasHeightForWidth());
        toolButton1_5->setSizePolicy(sizePolicy);
        toolButton1_5->setFont(font3);
        toolButton1_5->setStyleSheet(QString::fromUtf8(""));
        toolButton1_5->setIconSize(QSize(16, 16));
        toolButton1_6 = new QToolButton(centralWidget);
        toolButton1_6->setObjectName(QString::fromUtf8("toolButton1_6"));
        toolButton1_6->setGeometry(QRect(0, 480, 351, 71));
        sizePolicy.setHeightForWidth(toolButton1_6->sizePolicy().hasHeightForWidth());
        toolButton1_6->setSizePolicy(sizePolicy);
        toolButton1_6->setFont(font3);
        toolButton1_6->setStyleSheet(QString::fromUtf8(""));
        toolButton1_6->setIconSize(QSize(16, 16));
        toolButton1_7 = new QToolButton(centralWidget);
        toolButton1_7->setObjectName(QString::fromUtf8("toolButton1_7"));
        toolButton1_7->setGeometry(QRect(0, 550, 351, 71));
        sizePolicy.setHeightForWidth(toolButton1_7->sizePolicy().hasHeightForWidth());
        toolButton1_7->setSizePolicy(sizePolicy);
        toolButton1_7->setFont(font3);
        toolButton1_7->setStyleSheet(QString::fromUtf8(""));
        toolButton1_7->setIconSize(QSize(16, 16));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(300, 0, 51, 101));
        QFont font4;
        font4.setPointSize(30);
        pushButton->setFont(font4);
        chatroom = new QToolButton(centralWidget);
        chatroom->setObjectName(QString::fromUtf8("chatroom"));
        chatroom->setGeometry(QRect(0, 620, 351, 41));
        QFont font5;
        font5.setPointSize(20);
        font5.setItalic(true);
        chatroom->setFont(font5);
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 351, 28));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "user", nullptr));
        QTreeWidgetItem *___qtreewidgetitem = treeWidget->headerItem();
        ___qtreewidgetitem->setText(0, QCoreApplication::translate("MainWindow", "\346\210\221\347\232\204\345\245\275\345\217\213", nullptr));
        toolButton1_1->setText(QCoreApplication::translate("MainWindow", "wk", nullptr));
        toolButton1_2->setText(QCoreApplication::translate("MainWindow", "lj", nullptr));
        toolButton1_3->setText(QCoreApplication::translate("MainWindow", "zcl", nullptr));
        toolButton1_4->setText(QCoreApplication::translate("MainWindow", "lrh", nullptr));
        toolButton1_5->setText(QCoreApplication::translate("MainWindow", "jf", nullptr));
        toolButton1_6->setText(QCoreApplication::translate("MainWindow", "wyk", nullptr));
        toolButton1_7->setText(QCoreApplication::translate("MainWindow", "gdx", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "+", nullptr));
        chatroom->setText(QCoreApplication::translate("MainWindow", "\350\277\233\345\205\245\350\201\212\345\244\251\345\256\244", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
