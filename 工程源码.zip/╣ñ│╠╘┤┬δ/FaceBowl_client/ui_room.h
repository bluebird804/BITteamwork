/********************************************************************************
** Form generated from reading UI file 'room.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ROOM_H
#define UI_ROOM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_room
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QTextEdit *textEdit;
    QTextBrowser *textBrowser;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QFrame *frame;

    void setupUi(QDialog *room)
    {
        if (room->objectName().isEmpty())
            room->setObjectName(QString::fromUtf8("room"));
        room->resize(661, 569);
        pushButton = new QPushButton(room);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(300, 530, 93, 31));
        QFont font;
        font.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font.setPointSize(12);
        pushButton->setFont(font);
        pushButton->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background-color: rgba(233, 239, 255,100);\n"
"border-radius:4px;\n"
"}\n"
"QpushButton:pressed\n"
"{\n"
"background-color: rgba(255, 255, 255, 50);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"\n"
""));
        pushButton_2 = new QPushButton(room);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(410, 530, 93, 31));
        pushButton_2->setFont(font);
        pushButton_2->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background-color: rgba(233, 239, 255,100);\n"
"border-radius:4px;\n"
"}\n"
"QpushButton:pressed\n"
"{\n"
"background-color: rgba(255, 255, 255, 50);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"\n"
""));
        textEdit = new QTextEdit(room);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(10, 360, 501, 161));
        textEdit->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgba(255, 255, 255,233);\n"
"border-radius:5px;\n"
"\n"
""));
        textBrowser = new QTextBrowser(room);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(10, 20, 501, 331));
        textBrowser->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgba(255, 255, 255,233);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        label = new QLabel(room);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(560, 20, 72, 61));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font1.setPointSize(28);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setWeight(50);
        label->setFont(font1);
        label->setStyleSheet(QString::fromUtf8(""));
        label_2 = new QLabel(room);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(560, 90, 72, 61));
        label_2->setStyleSheet(QString::fromUtf8("font: 28pt \"\351\273\221\344\275\223\";"));
        label_3 = new QLabel(room);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(560, 170, 72, 51));
        label_3->setStyleSheet(QString::fromUtf8("font: 28pt \"\351\273\221\344\275\223\";"));
        label_4 = new QLabel(room);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(560, 390, 72, 61));
        label_4->setStyleSheet(QString::fromUtf8("font: 28pt \"\351\273\221\344\275\223\";"));
        label_5 = new QLabel(room);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(560, 320, 72, 61));
        label_5->setStyleSheet(QString::fromUtf8("font: 28pt \"\351\273\221\344\275\223\";"));
        label_6 = new QLabel(room);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(560, 240, 72, 61));
        label_6->setStyleSheet(QString::fromUtf8("font: 28pt \"\351\273\221\344\275\223\";"));
        label_7 = new QLabel(room);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(560, 460, 72, 61));
        label_7->setStyleSheet(QString::fromUtf8("font: 28pt \"\351\273\221\344\275\223\";"));
        frame = new QFrame(room);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(0, -1, 661, 571));
        frame->setStyleSheet(QString::fromUtf8("\n"
"border-image: url(:/77777.png);"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        frame->raise();
        pushButton->raise();
        pushButton_2->raise();
        textEdit->raise();
        textBrowser->raise();
        label->raise();
        label_2->raise();
        label_3->raise();
        label_4->raise();
        label_5->raise();
        label_6->raise();
        label_7->raise();

        retranslateUi(room);

        QMetaObject::connectSlotsByName(room);
    } // setupUi

    void retranslateUi(QDialog *room)
    {
        room->setWindowTitle(QCoreApplication::translate("room", "\350\201\212\345\244\251\345\256\244", nullptr));
        pushButton->setText(QCoreApplication::translate("room", "\345\217\221\351\200\201\346\226\207\344\273\266", nullptr));
        pushButton_2->setText(QCoreApplication::translate("room", "\345\217\221\351\200\201", nullptr));
        label->setText(QCoreApplication::translate("room", "\346\254\242", nullptr));
        label_2->setText(QCoreApplication::translate("room", "\350\277\216", nullptr));
        label_3->setText(QCoreApplication::translate("room", "\346\235\245", nullptr));
        label_4->setText(QCoreApplication::translate("room", "\345\244\251", nullptr));
        label_5->setText(QCoreApplication::translate("room", "\350\201\212", nullptr));
        label_6->setText(QCoreApplication::translate("room", "\345\210\260", nullptr));
        label_7->setText(QCoreApplication::translate("room", "\345\256\244", nullptr));
    } // retranslateUi

};

namespace Ui {
    class room: public Ui_room {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ROOM_H
