/********************************************************************************
** Form generated from reading UI file 'wait.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WAIT_H
#define UI_WAIT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_wait
{
public:
    QLabel *label;

    void setupUi(QDialog *wait)
    {
        if (wait->objectName().isEmpty())
            wait->setObjectName(QString::fromUtf8("wait"));
        wait->resize(372, 141);
        wait->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(0, 69, 170, 56), stop:1 rgba(255, 255, 255, 255));"));
        label = new QLabel(wait);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(140, 50, 111, 41));
        label->setStyleSheet(QString::fromUtf8("font: 12pt \"\351\273\221\344\275\223\";\n"
"background-color: rgba(255, 255, 255, 0);"));

        retranslateUi(wait);

        QMetaObject::connectSlotsByName(wait);
    } // setupUi

    void retranslateUi(QDialog *wait)
    {
        wait->setWindowTitle(QCoreApplication::translate("wait", "\345\267\262\345\217\221\351\200\201", nullptr));
        label->setText(QCoreApplication::translate("wait", "\351\202\200\350\257\267\345\267\262\345\217\221\351\200\201", nullptr));
    } // retranslateUi

};

namespace Ui {
    class wait: public Ui_wait {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WAIT_H
