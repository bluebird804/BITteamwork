/********************************************************************************
** Form generated from reading UI file 'receivejindutiao.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RECEIVEJINDUTIAO_H
#define UI_RECEIVEJINDUTIAO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_receivejindutiao
{
public:
    QProgressBar *progressBar;
    QPushButton *pushButton;
    QLabel *label;
    QFrame *frame;

    void setupUi(QDialog *receivejindutiao)
    {
        if (receivejindutiao->objectName().isEmpty())
            receivejindutiao->setObjectName(QString::fromUtf8("receivejindutiao"));
        receivejindutiao->resize(400, 300);
        progressBar = new QProgressBar(receivejindutiao);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setGeometry(QRect(110, 130, 271, 41));
        QFont font;
        font.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        progressBar->setFont(font);
        progressBar->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgba(255, 255, 255, 255);\n"
"border-radius:2px;\n"
"\n"
""));
        progressBar->setValue(24);
        pushButton = new QPushButton(receivejindutiao);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(160, 240, 91, 31));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font1.setPointSize(12);
        pushButton->setFont(font1);
        pushButton->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background-color: rgba(233, 239, 255,100);\n"
"border-radius:4px;\n"
"}\n"
"QpushButton:pressed\n"
"{\n"
"background-color: rgba(255, 255, 255, 50);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"\n"
""));
        label = new QLabel(receivejindutiao);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(300, 180, 81, 21));
        QFont font2;
        font2.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font2.setPointSize(10);
        label->setFont(font2);
        frame = new QFrame(receivejindutiao);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(0, 0, 401, 301));
        frame->setStyleSheet(QString::fromUtf8("border-image: url(:/8888.png);"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        frame->raise();
        progressBar->raise();
        pushButton->raise();
        label->raise();

        retranslateUi(receivejindutiao);

        QMetaObject::connectSlotsByName(receivejindutiao);
    } // setupUi

    void retranslateUi(QDialog *receivejindutiao)
    {
        receivejindutiao->setWindowTitle(QCoreApplication::translate("receivejindutiao", "\346\216\245\346\224\266\344\270\255...", nullptr));
        pushButton->setText(QCoreApplication::translate("receivejindutiao", "\345\217\226\346\266\210\346\216\245\346\224\266", nullptr));
        label->setText(QCoreApplication::translate("receivejindutiao", "\346\216\245\346\224\266\344\270\255...", nullptr));
    } // retranslateUi

};

namespace Ui {
    class receivejindutiao: public Ui_receivejindutiao {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RECEIVEJINDUTIAO_H
