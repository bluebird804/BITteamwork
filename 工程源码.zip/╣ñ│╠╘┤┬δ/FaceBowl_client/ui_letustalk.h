/********************************************************************************
** Form generated from reading UI file 'letustalk.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LETUSTALK_H
#define UI_LETUSTALK_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_letustalk
{
public:
    QTextEdit *textEdit;
    QLabel *label_3;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_4;
    QTextBrowser *textBrowser;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QWidget *widget;

    void setupUi(QDialog *letustalk)
    {
        if (letustalk->objectName().isEmpty())
            letustalk->setObjectName(QString::fromUtf8("letustalk"));
        letustalk->resize(701, 578);
        textEdit = new QTextEdit(letustalk);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(20, 380, 511, 151));
        textEdit->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgba(255, 255, 255,200);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        label_3 = new QLabel(letustalk);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(540, 400, 151, 31));
        QFont font;
        font.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        label_3->setFont(font);
        label = new QLabel(letustalk);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(540, 100, 151, 31));
        label->setFont(font);
        label_2 = new QLabel(letustalk);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(540, 130, 151, 31));
        label_2->setFont(font);
        label_4 = new QLabel(letustalk);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(540, 430, 151, 31));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font1.setPointSize(9);
        label_4->setFont(font1);
        textBrowser = new QTextBrowser(letustalk);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(20, 20, 511, 351));
        textBrowser->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgba(255, 255, 255,200);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        pushButton = new QPushButton(letustalk);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(310, 540, 93, 31));
        QFont font2;
        font2.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font2.setPointSize(12);
        pushButton->setFont(font2);
        pushButton->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background-color: rgba(233, 239, 255,50);\n"
"border-radius:4px;\n"
"}\n"
"QpushButton:pressed\n"
"{\n"
"background-color: rgba(255, 255, 255, 50);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"\n"
""));
        pushButton_2 = new QPushButton(letustalk);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(430, 540, 93, 31));
        pushButton_2->setFont(font2);
        pushButton_2->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background-color: rgba(233, 239, 255,50);\n"
"border-radius:4px;\n"
"}\n"
"QpushButton:pressed\n"
"{\n"
"background-color: rgba(255, 255, 255, 50);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"\n"
""));
        pushButton_3 = new QPushButton(letustalk);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(540, 220, 151, 28));
        pushButton_3->setFont(font2);
        pushButton_3->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background-color: rgba(233, 239, 255,50);\n"
"border-radius:4px;\n"
"}\n"
"QpushButton:pressed\n"
"{\n"
"background-color: rgba(255, 255, 255, 50);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"\n"
""));
        widget = new QWidget(letustalk);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(0, 0, 701, 581));
        widget->setStyleSheet(QString::fromUtf8("border-image: url(:/77777.png);"));
        widget->raise();
        textEdit->raise();
        label_3->raise();
        label->raise();
        label_2->raise();
        label_4->raise();
        textBrowser->raise();
        pushButton->raise();
        pushButton_2->raise();
        pushButton_3->raise();

        retranslateUi(letustalk);

        QMetaObject::connectSlotsByName(letustalk);
    } // setupUi

    void retranslateUi(QDialog *letustalk)
    {
        letustalk->setWindowTitle(QCoreApplication::translate("letustalk", "\350\201\212\345\244\251", nullptr));
        label_3->setText(QCoreApplication::translate("letustalk", "\347\224\250\346\210\267\345\220\215", nullptr));
        label->setText(QCoreApplication::translate("letustalk", "\347\224\250\346\210\267\345\220\215", nullptr));
        label_2->setText(QCoreApplication::translate("letustalk", "IP\345\234\260\345\235\200", nullptr));
        label_4->setText(QCoreApplication::translate("letustalk", "IP\345\234\260\345\235\200", nullptr));
        pushButton->setText(QCoreApplication::translate("letustalk", "\345\217\221\351\200\201\346\226\207\344\273\266", nullptr));
        pushButton_2->setText(QCoreApplication::translate("letustalk", "\345\217\221\351\200\201", nullptr));
        pushButton_3->setText(QCoreApplication::translate("letustalk", "\345\257\271\346\226\271\346\255\243\345\234\250\345\217\221\351\200\201\346\226\260\346\226\207\344\273\266", nullptr));
    } // retranslateUi

};

namespace Ui {
    class letustalk: public Ui_letustalk {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LETUSTALK_H
