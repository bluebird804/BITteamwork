#include "findfri.h"
#include "ui_findfri.h"
#include "invite.h"

FindFri::FindFri(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::FindFri)
{
    ui->setupUi(this);
    setWindowIcon(QIcon(QStringLiteral(":/icon.png")));
}

FindFri::~FindFri()
{
    delete ui;
}

void FindFri::on_clsbtn_clicked()
{
    this->close();
}

void FindFri::on_cfmbtn_clicked()
{
    Invite i;
    i.exec();
}
