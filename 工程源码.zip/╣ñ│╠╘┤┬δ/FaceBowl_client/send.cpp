#include "send.h"
#include "ui_send.h"

send::send(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::send)
{
    ui->setupUi(this);
    setWindowIcon(QIcon(QStringLiteral(":/icon.png")));
    this->m_socket=new QTcpSocket(this);
    this->m_socket->connectToHost(QHostAddress::LocalHost,520);
    connect(this->m_socket,SIGNAL(connected()),this,SLOT(connected()));
}

send::~send()
{
    delete ui;
}
//显示文件路径
void send::on_pushButton_clicked()
{
     path=QDir::toNativeSeparators(QFileDialog::getOpenFileName(this,tr("Save path"),QDir::currentPath()));  //文件路径
            if(!path.isEmpty())
            {
                if(ui->comboBox->findText(path)==-1)
                    ui->comboBox->addItem(path);    //在comboBox中显示文件路径
            }
}

void send::on_pushButton_2_clicked()
{
    /*********打开文件*********/
    QFile f(path);
    f.open(QIODevice::ReadOnly);
    /******二进制数据块******/
    QByteArray block;
    /******读取文件**********/
    QByteArray data=f.readAll();
    /*********设置数据流***********/
    QDataStream dts(&block,QIODevice::WriteOnly);
    /*****先格式化数据块*********/
    dts<<qint64(0)<<qint64(0)<<QString("xx.txt");
    /*******指向头部*************/
    dts.device()->seek(0);
    /*******计算数据总大小*********/
    dts<<(qint64)(block.size()+f.size());
    //QMessageBox::about(this,"x",QString::number((qint64)(block.size()+f.size())));
    /**********文件名大小（所占空间）***************/
    dts<<(qint64)(block.size()-sizeof(qint64)*2);
     //QMessageBox::about(this,"x",QString::number((qint64)(block.size()-sizeof(qint64)*2)));
     /********再次占位**********/
    dts<<QString("xx.txt");
    /*********写入文件数据***********/
    dts<<data;
    //QMessageBox::about(this,"x",QString::number(block.size()));
    /*******发送*********/
    this->m_socket->write(block);
}
