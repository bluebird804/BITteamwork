#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "findfri.h"
#include "tcpclient.h"
#include "letustalk.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowIcon(QIcon(QStringLiteral(":/icon.png")));

    ui->toolButton1_1->setIcon( QPixmap(":/2.jpg") );
    ui->toolButton1_1->setIconSize( QPixmap(":/2.jpg").size() );
    ui->toolButton1_1->setAutoRaise(true);
    ui->toolButton1_1->setToolButtonStyle( Qt::ToolButtonTextBesideIcon);

    ui->toolButton1_2->setIcon( QPixmap(":/3.jpg") );
    ui->toolButton1_2->setIconSize( QPixmap(":/3.jpg").size() );
    ui->toolButton1_2->setAutoRaise(true);
    ui->toolButton1_2->setToolButtonStyle( Qt::ToolButtonTextBesideIcon);

    ui->toolButton1_3->setIcon( QPixmap(":/4.jpg") );
    ui->toolButton1_3->setIconSize( QPixmap(":/4.jpg").size() );
    ui->toolButton1_3->setAutoRaise(true);
    ui->toolButton1_3->setToolButtonStyle( Qt::ToolButtonTextBesideIcon);

    ui->toolButton1_4->setIcon( QPixmap(":/5.jpg") );
    ui->toolButton1_4->setIconSize( QPixmap(":/5.jpg").size() );
    ui->toolButton1_4->setAutoRaise(true);
    ui->toolButton1_4->setToolButtonStyle( Qt::ToolButtonTextBesideIcon);

    ui->toolButton1_5->setIcon( QPixmap(":/6.jpg") );
    ui->toolButton1_5->setIconSize( QPixmap(":/6.jpg").size() );
    ui->toolButton1_5->setAutoRaise(true);
    ui->toolButton1_5->setToolButtonStyle( Qt::ToolButtonTextBesideIcon);

    ui->toolButton1_6->setIcon( QPixmap(":/7.jpg") );
    ui->toolButton1_6->setIconSize( QPixmap(":/7.jpg").size() );
    ui->toolButton1_6->setAutoRaise(true);
    ui->toolButton1_6->setToolButtonStyle( Qt::ToolButtonTextBesideIcon);

    ui->toolButton1_7->setIcon( QPixmap(":/1.jpg") );
    ui->toolButton1_7->setIconSize( QPixmap(":/1.jpg").size() );
    ui->toolButton1_7->setAutoRaise(true);
    ui->toolButton1_7->setToolButtonStyle( Qt::ToolButtonTextBesideIcon);

;}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{

    FindFri f;
    f.exec();
}

void MainWindow::on_chatroom_clicked()
{
    TcpClient t;
    t.exec();
}

void MainWindow::on_toolButton1_1_clicked()
{
    letustalk l1;
    l1.exec();
}
