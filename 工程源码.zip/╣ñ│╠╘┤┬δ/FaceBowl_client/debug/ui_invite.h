/********************************************************************************
** Form generated from reading UI file 'invite.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INVITE_H
#define UI_INVITE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_Invite
{
public:
    QLabel *label;

    void setupUi(QDialog *Invite)
    {
        if (Invite->objectName().isEmpty())
            Invite->setObjectName(QStringLiteral("Invite"));
        Invite->resize(400, 300);
        label = new QLabel(Invite);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(100, 110, 211, 71));
        QFont font;
        font.setPointSize(20);
        label->setFont(font);

        retranslateUi(Invite);

        QMetaObject::connectSlotsByName(Invite);
    } // setupUi

    void retranslateUi(QDialog *Invite)
    {
        Invite->setWindowTitle(QApplication::translate("Invite", "Dialog", Q_NULLPTR));
        label->setText(QApplication::translate("Invite", "\345\245\275\345\217\213\350\257\267\346\261\202\345\267\262\345\217\221\351\200\201", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Invite: public Ui_Invite {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INVITE_H
