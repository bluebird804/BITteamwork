/********************************************************************************
** Form generated from reading UI file 'receivejindutiao.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RECEIVEJINDUTIAO_H
#define UI_RECEIVEJINDUTIAO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_receivejindutiao
{
public:
    QProgressBar *progressBar;
    QPushButton *pushButton;
    QLabel *label;
    QFrame *frame;

    void setupUi(QDialog *receivejindutiao)
    {
        if (receivejindutiao->objectName().isEmpty())
            receivejindutiao->setObjectName(QStringLiteral("receivejindutiao"));
        receivejindutiao->resize(400, 300);
        progressBar = new QProgressBar(receivejindutiao);
        progressBar->setObjectName(QStringLiteral("progressBar"));
        progressBar->setGeometry(QRect(110, 130, 271, 41));
        QFont font;
        font.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        progressBar->setFont(font);
        progressBar->setStyleSheet(QLatin1String("\n"
"background-color: rgba(255, 255, 255, 255);\n"
"border-radius:2px;\n"
"\n"
""));
        progressBar->setValue(24);
        pushButton = new QPushButton(receivejindutiao);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(160, 240, 91, 31));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font1.setPointSize(12);
        pushButton->setFont(font1);
        pushButton->setStyleSheet(QLatin1String("QPushButton\n"
"{\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background-color: rgba(233, 239, 255,100);\n"
"border-radius:4px;\n"
"}\n"
"QpushButton:pressed\n"
"{\n"
"background-color: rgba(255, 255, 255, 50);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"\n"
""));
        label = new QLabel(receivejindutiao);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(300, 180, 81, 21));
        QFont font2;
        font2.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font2.setPointSize(10);
        label->setFont(font2);
        frame = new QFrame(receivejindutiao);
        frame->setObjectName(QStringLiteral("frame"));
        frame->setGeometry(QRect(0, 0, 401, 301));
        frame->setStyleSheet(QStringLiteral("border-image: url(:/8888.png);"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        frame->raise();
        progressBar->raise();
        pushButton->raise();
        label->raise();

        retranslateUi(receivejindutiao);

        QMetaObject::connectSlotsByName(receivejindutiao);
    } // setupUi

    void retranslateUi(QDialog *receivejindutiao)
    {
        receivejindutiao->setWindowTitle(QApplication::translate("receivejindutiao", "\346\216\245\346\224\266\344\270\255...", Q_NULLPTR));
        pushButton->setText(QApplication::translate("receivejindutiao", "\345\217\226\346\266\210\346\216\245\346\224\266", Q_NULLPTR));
        label->setText(QApplication::translate("receivejindutiao", "\346\216\245\346\224\266\344\270\255...", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class receivejindutiao: public Ui_receivejindutiao {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RECEIVEJINDUTIAO_H
