/********************************************************************************
** Form generated from reading UI file 'friendadded.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FRIENDADDED_H
#define UI_FRIENDADDED_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_friendadded
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLabel *label;

    void setupUi(QDialog *friendadded)
    {
        if (friendadded->objectName().isEmpty())
            friendadded->setObjectName(QStringLiteral("friendadded"));
        friendadded->resize(342, 140);
        friendadded->setStyleSheet(QStringLiteral("QDialog{background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(0, 69, 170, 56), stop:1 rgba(255, 255, 255, 255));}"));
        pushButton = new QPushButton(friendadded);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(40, 100, 93, 28));
        QFont font;
        font.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font.setPointSize(12);
        pushButton->setFont(font);
        pushButton->setStyleSheet(QLatin1String("QPushButton\n"
"{\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background-color: rgba(233, 239, 255,200);\n"
"border-radius:4px;\n"
"}\n"
"QpushButton:pressed\n"
"{\n"
"background-color: rgba(255, 255, 255, 50);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"\n"
""));
        pushButton_2 = new QPushButton(friendadded);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(200, 100, 93, 28));
        pushButton_2->setFont(font);
        pushButton_2->setStyleSheet(QLatin1String("QPushButton\n"
"{\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background-color: rgba(233, 239, 255,200);\n"
"border-radius:4px;\n"
"}\n"
"QpushButton:pressed\n"
"{\n"
"background-color: rgba(255, 255, 255, 50);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"\n"
""));
        label = new QLabel(friendadded);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(110, 40, 191, 31));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font1.setPointSize(10);
        label->setFont(font1);

        retranslateUi(friendadded);

        QMetaObject::connectSlotsByName(friendadded);
    } // setupUi

    void retranslateUi(QDialog *friendadded)
    {
        friendadded->setWindowTitle(QApplication::translate("friendadded", "\346\267\273\345\212\240\345\245\275\345\217\213\350\257\267\346\261\202", Q_NULLPTR));
        pushButton->setText(QApplication::translate("friendadded", "\345\220\214\346\204\217", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("friendadded", "\346\213\222\347\273\235", Q_NULLPTR));
        label->setText(QApplication::translate("friendadded", "...\350\257\267\346\261\202\346\267\273\345\212\240\346\202\250\344\270\272\345\245\275\345\217\213", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class friendadded: public Ui_friendadded {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FRIENDADDED_H
