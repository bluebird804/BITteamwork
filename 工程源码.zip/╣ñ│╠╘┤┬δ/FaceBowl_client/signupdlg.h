#ifndef SIGNUPDLG_H
#define SIGNUPDLG_H

#include <QDialog>
#include <QTcpSocket>

namespace Ui {
class signupdlg;
}

class signupdlg : public QDialog
{
    Q_OBJECT

public:
    explicit signupdlg(QWidget *parent = nullptr);
    ~signupdlg();

private slots:
    void on_cfmbtn_clicked();
    void send();
    void cnctsvr();
    void connted();
    void disconnect();
private:
    Ui::signupdlg *ui;
    QTcpSocket *socket;
    bool isconnected;
};

#endif // SIGNUPDLG_H
