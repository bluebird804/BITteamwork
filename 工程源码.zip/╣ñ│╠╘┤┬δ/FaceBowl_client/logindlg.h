#ifndef LOGINDLG_H
#define LOGINDLG_H

#include <QDialog>
#include <QTcpSocket>

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = nullptr);
    bool judge;
    ~Dialog();

private slots:
    void on_loginbtn_clicked();
    void on_checkBox_stateChanged();
    void on_sinupbtn_clicked();
    void cnctsvr();
    void send();
    void read();
    void connted();
    void disconnect();

private:
    Ui::Dialog *ui;
    QTcpSocket *socket;
    bool isconnected;
};

#endif // LOGINDLG_H
