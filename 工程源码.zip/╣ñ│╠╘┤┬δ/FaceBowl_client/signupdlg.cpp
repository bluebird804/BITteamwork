#include "signupdlg.h"
#include "ui_signupdlg.h"
#include <QString>
#include <QMessageBox>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>
#include <QDebug>

signupdlg::signupdlg(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::signupdlg)
{
    ui->setupUi(this);
    setWindowIcon(QIcon(QStringLiteral(":/icon.png")));
    cnctsvr();
    /*QSqlDatabase db=QSqlDatabase::addDatabase("QSQLITE");
    db.setHostName("10.195.30.207");   //数据库服务器ip
    db.setUserName("root");        //数据库用户名
    db.setPassword("123456");      //密码
    db.setDatabaseName("info");    //使用哪个数据库
    if(!db.open())
    {
        QMessageBox::warning(this, "错误", db.lastError().text());
        return;
    }
    QSqlQuery query;
    query.prepare("CREATE TABLE usr(name varchar,password varchar)");
    query.exec();*/
}

signupdlg::~signupdlg()
{
    delete ui;
}

void signupdlg::on_cfmbtn_clicked()
{
    send();
    QString user=ui->usnmedit->text();
    QString passwd=ui->pswdedit->text();
    QString confirm=ui->pswdcfm->text();
    if(!user.isEmpty()&&!passwd.isEmpty()&&!confirm.isEmpty()&&passwd==confirm)
    {
        QMessageBox::information(NULL, "注册成功", "注册成功！！！", QMessageBox::Yes);
        disconnect();
        accept();
    }
    else if(user.isEmpty())
    {
        QMessageBox::warning(this, "错误", "请输入用户名");
    }
    else if(passwd.isEmpty())
    {
        QMessageBox::warning(this, "错误", "请输入密码");
    }
    else if(confirm.isEmpty())
    {
        QMessageBox::warning(this, "错误", "请再次确认密码");
    }
    else
    {
        QMessageBox::warning(this, "错误", "密码不一致");
    }
}

void signupdlg::cnctsvr()
{
    socket=new QTcpSocket(this);
    socket->abort();
    socket->connectToHost("192.168.43.218",6666);
    connect(socket,SIGNAL(connected()),this,SLOT(connted()));
}

void signupdlg::connted()
{
    this->isconnected =true;
    //QMessageBox::information(NULL, "连接成功", "注册连接成功！！！", QMessageBox::Yes);
}

void signupdlg::send()
{
    if(this->isconnected)
        {
            QString name = ui->usnmedit->text(); //从单行文本框获得要发送消息
            QString password=ui->pswdedit->text();
            if(!name.isEmpty())
            {
                //发送消息到服务器
                this->socket->write("2");
                this->socket->write(name.toLatin1());
                this->socket->write(",");
                this->socket->write(password.toLatin1());
                //QMessageBox::information(NULL, "发送", "发送成功！！！", QMessageBox::Yes);
                //本地显示发送的消息
                /*QString localDispalyMessage = tr("send to server: ") + sendMessage \
                                                + QDateTime::currentDateTime().toString(" yyyy-M-dd hh:mm:ss") + tr("\n");
                ui->textBrowser->append(localDispalyMessage);*/
            }
            //else
                //QMessageBox::warning(this,"错误","消息不能为空!",QMessageBox::Ok);
        }
        else
            QMessageBox::warning(this,"错误","未连接到服务器!",QMessageBox::Ok);

}

void signupdlg::disconnect()
{
    if(socket != nullptr)
    {
        //QMessageBox::warning(this,"错误","断开注册连接!",QMessageBox::Ok);
        socket->close(); //关闭客户端
        socket->deleteLater();
    }
}


