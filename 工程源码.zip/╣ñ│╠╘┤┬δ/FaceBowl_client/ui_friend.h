/********************************************************************************
** Form generated from reading UI file 'friend.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FRIEND_H
#define UI_FRIEND_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QTextBrowser>

QT_BEGIN_NAMESPACE

class Ui_friend
{
public:
    QLabel *label;
    QTextBrowser *textBrowser;

    void setupUi(QDialog *friend)
    {
        if (friend->objectName().isEmpty())
            friend->setObjectName(QString::fromUtf8("friend"));
        friend->resize(320, 598);
        label = new QLabel(friend);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 10, 91, 31));
        textBrowser = new QTextBrowser(friend);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(0, 41, 311, 551));

        retranslateUi(friend);

        QMetaObject::connectSlotsByName(friend);
    } // setupUi

    void retranslateUi(QDialog *friend)
    {
        friend->setWindowTitle(QCoreApplication::translate("friend", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("friend", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class friend: public Ui_friend {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FRIEND_H
