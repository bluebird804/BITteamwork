#ifndef SEND_H
#define SEND_H

#include <QDialog>
#include <QFileDialog>
#include <QDebug>
#include <QComboBox>
#include <QFile>
#include <QWidget>
#include "QDir"
#include "QTextStream"

#include<QByteArray>
#include<QDataStream>
#include<QString>
#include<QTcpServer>
#include<QFile>
#include<QUrl>
#include<QHostAddress>
#include<QTcpSocket>
#include<QMessageBox>

namespace Ui {
class send;
}

class send : public QDialog
{
    Q_OBJECT

public:
    explicit send(QWidget *parent = 0);
    ~send();

private slots:
    void on_pushButton_clicked();//添加文件路径
    void on_pushButton_2_clicked();

private:
    QString path;
    qint64 m_bytestotal;
    qint64 m_bytesreceived;
    QTcpSocket * m_socket;
    Ui::send *ui;
};

#endif // SEND_H
