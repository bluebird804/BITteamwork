/********************************************************************************
** Form generated from reading UI file 'jindutiao.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_JINDUTIAO_H
#define UI_JINDUTIAO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_jindutiao
{
public:
    QProgressBar *progressBar;
    QPushButton *pushButton;
    QLabel *label;
    QWidget *widget;

    void setupUi(QDialog *jindutiao)
    {
        if (jindutiao->objectName().isEmpty())
            jindutiao->setObjectName(QString::fromUtf8("jindutiao"));
        jindutiao->resize(400, 300);
        jindutiao->setStyleSheet(QString::fromUtf8(""));
        progressBar = new QProgressBar(jindutiao);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setGeometry(QRect(100, 110, 251, 41));
        progressBar->setValue(24);
        pushButton = new QPushButton(jindutiao);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(150, 220, 101, 31));
        QFont font;
        font.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font.setPointSize(12);
        pushButton->setFont(font);
        pushButton->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background-color: rgba(233, 239, 255,100);\n"
"border-radius:4px;\n"
"}\n"
"QpushButton:pressed\n"
"{\n"
"background-color: rgba(255, 255, 255, 50);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"\n"
""));
        label = new QLabel(jindutiao);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(160, 180, 72, 20));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font1.setPointSize(12);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setWeight(50);
        label->setFont(font1);
        label->setStyleSheet(QString::fromUtf8(""));
        widget = new QWidget(jindutiao);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(0, -1, 401, 301));
        widget->setStyleSheet(QString::fromUtf8("border-image: url(:/8888.png);"));
        widget->raise();
        progressBar->raise();
        pushButton->raise();
        label->raise();

        retranslateUi(jindutiao);

        QMetaObject::connectSlotsByName(jindutiao);
    } // setupUi

    void retranslateUi(QDialog *jindutiao)
    {
        jindutiao->setWindowTitle(QCoreApplication::translate("jindutiao", "\345\217\221\351\200\201\344\270\255...", nullptr));
        pushButton->setText(QCoreApplication::translate("jindutiao", "\345\217\226\346\266\210\345\217\221\351\200\201", nullptr));
        label->setText(QCoreApplication::translate("jindutiao", "\345\217\221\351\200\201\344\270\255...", nullptr));
    } // retranslateUi

};

namespace Ui {
    class jindutiao: public Ui_jindutiao {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_JINDUTIAO_H
