/********************************************************************************
** Form generated from reading UI file 'signupdlg.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SIGNUPDLG_H
#define UI_SIGNUPDLG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_signupdlg
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLineEdit *usnmedit;
    QLineEdit *pswdedit;
    QLineEdit *pswdcfm;
    QPushButton *cfmbtn;
    QWidget *widget;
    QWidget *widget_2;

    void setupUi(QDialog *signupdlg)
    {
        if (signupdlg->objectName().isEmpty())
            signupdlg->setObjectName(QStringLiteral("signupdlg"));
        signupdlg->resize(360, 341);
        signupdlg->setStyleSheet(QStringLiteral(""));
        label = new QLabel(signupdlg);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(60, 150, 67, 25));
        label->setStyleSheet(QString::fromUtf8("font: 12pt \"\351\273\221\344\275\223\";\n"
"background-color: rgba(255, 255, 255,0);\n"
""));
        label_2 = new QLabel(signupdlg);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(60, 190, 67, 25));
        label_2->setStyleSheet(QString::fromUtf8("font: 12pt \"\351\273\221\344\275\223\";\n"
"background-color: rgba(255, 255, 255, 0);\n"
""));
        label_3 = new QLabel(signupdlg);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(60, 230, 111, 25));
        label_3->setStyleSheet(QString::fromUtf8("font: 12pt \"\351\273\221\344\275\223\";\n"
"background-color: rgba(255, 255, 255, 0);\n"
""));
        usnmedit = new QLineEdit(signupdlg);
        usnmedit->setObjectName(QStringLiteral("usnmedit"));
        usnmedit->setGeometry(QRect(150, 150, 151, 25));
        usnmedit->setAutoFillBackground(false);
        usnmedit->setStyleSheet(QString::fromUtf8("font: 9pt \"\351\273\221\344\275\223\";\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;"));
        pswdedit = new QLineEdit(signupdlg);
        pswdedit->setObjectName(QStringLiteral("pswdedit"));
        pswdedit->setGeometry(QRect(150, 190, 151, 25));
        pswdedit->setStyleSheet(QString::fromUtf8("font: 9pt \"\351\273\221\344\275\223\";\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;"));
        pswdcfm = new QLineEdit(signupdlg);
        pswdcfm->setObjectName(QStringLiteral("pswdcfm"));
        pswdcfm->setGeometry(QRect(150, 230, 151, 25));
        pswdcfm->setStyleSheet(QString::fromUtf8("font: 9pt \"\351\273\221\344\275\223\";\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;"));
        cfmbtn = new QPushButton(signupdlg);
        cfmbtn->setObjectName(QStringLiteral("cfmbtn"));
        cfmbtn->setGeometry(QRect(50, 280, 89, 25));
        cfmbtn->setStyleSheet(QString::fromUtf8("font: 12pt \"\351\273\221\344\275\223\";\n"
"background-color: rgba(255, 255, 255, 120);\n"
"border-radius:10px;\n"
""));
        widget = new QWidget(signupdlg);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(0, -20, 361, 151));
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(255, 255, 255, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        palette.setBrush(QPalette::Active, QPalette::Light, brush1);
        palette.setBrush(QPalette::Active, QPalette::Midlight, brush1);
        QBrush brush2(QColor(127, 127, 127, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Dark, brush2);
        QBrush brush3(QColor(170, 170, 170, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Mid, brush3);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        palette.setBrush(QPalette::Active, QPalette::BrightText, brush1);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush1);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Active, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush1);
        QBrush brush4(QColor(255, 255, 220, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ToolTipBase, brush4);
        palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Dark, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::Mid, brush3);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::BrightText, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush4);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Dark, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Mid, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::BrightText, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
        widget->setPalette(palette);
        widget->setStyleSheet(QLatin1String("\n"
"border-image: url(:/new/prefix1/back.gif);"));
        widget_2 = new QWidget(signupdlg);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        widget_2->setGeometry(QRect(0, 130, 361, 211));
        widget_2->setStyleSheet(QLatin1String("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(255, 235, 235, 206), stop:0.35 rgba(255, 188, 188, 80), stop:0.4 rgba(255, 162, 162, 80), stop:0.425 rgba(255, 132, 132, 156), stop:0.44 rgba(252, 128, 128, 80), stop:1 rgba(255, 255, 255, 0));\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(0, 69, 170, 56), stop:1 rgba(255, 255, 255, 255));"));
        widget_2->raise();
        label->raise();
        label_2->raise();
        label_3->raise();
        usnmedit->raise();
        pswdedit->raise();
        pswdcfm->raise();
        cfmbtn->raise();
        widget->raise();

        retranslateUi(signupdlg);

        QMetaObject::connectSlotsByName(signupdlg);
    } // setupUi

    void retranslateUi(QDialog *signupdlg)
    {
        signupdlg->setWindowTitle(QApplication::translate("signupdlg", "\346\263\250\345\206\214", Q_NULLPTR));
        label->setText(QApplication::translate("signupdlg", "\347\224\250\346\210\267\345\220\215\357\274\232", Q_NULLPTR));
        label_2->setText(QApplication::translate("signupdlg", "\345\257\206\347\240\201\357\274\232", Q_NULLPTR));
        label_3->setText(QApplication::translate("signupdlg", "\347\241\256\350\256\244\345\257\206\347\240\201\357\274\232", Q_NULLPTR));
        usnmedit->setPlaceholderText(QApplication::translate("signupdlg", "username", Q_NULLPTR));
        pswdedit->setPlaceholderText(QApplication::translate("signupdlg", "password", Q_NULLPTR));
        cfmbtn->setText(QApplication::translate("signupdlg", "\347\241\256\350\256\244", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class signupdlg: public Ui_signupdlg {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SIGNUPDLG_H
