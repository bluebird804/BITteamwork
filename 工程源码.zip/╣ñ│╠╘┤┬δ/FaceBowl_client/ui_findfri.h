/********************************************************************************
** Form generated from reading UI file 'findfri.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FINDFRI_H
#define UI_FINDFRI_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_FindFri
{
public:
    QTextEdit *textEdit;
    QLabel *label;
    QPushButton *cfmbtn;
    QPushButton *clsbtn;
    QLabel *label_2;

    void setupUi(QDialog *FindFri)
    {
        if (FindFri->objectName().isEmpty())
            FindFri->setObjectName(QString::fromUtf8("FindFri"));
        FindFri->resize(400, 300);
        FindFri->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n"
"background-color: qlineargradient(spread:pad, x1:0.196, y1:0, x2:1, y2:0, stop:0 rgba(114, 159, 207, 255), stop:1 rgba(255, 255, 255, 255));"));
        textEdit = new QTextEdit(FindFri);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(140, 120, 171, 41));
        QFont font;
        font.setPointSize(16);
        textEdit->setFont(font);
        textEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(238, 238, 236);"));
        label = new QLabel(FindFri);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 401, 51));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Purisa"));
        font1.setPointSize(20);
        font1.setBold(true);
        font1.setItalic(true);
        font1.setWeight(75);
        font1.setStrikeOut(false);
        label->setFont(font1);
        cfmbtn = new QPushButton(FindFri);
        cfmbtn->setObjectName(QString::fromUtf8("cfmbtn"));
        cfmbtn->setGeometry(QRect(230, 230, 89, 25));
        cfmbtn->setStyleSheet(QString::fromUtf8("font: 12pt \"\351\273\221\344\275\223\";\n"
"background-color: rgba(255, 255, 255, 120);\n"
"border-radius:10px;\n"
""));
        clsbtn = new QPushButton(FindFri);
        clsbtn->setObjectName(QString::fromUtf8("clsbtn"));
        clsbtn->setGeometry(QRect(80, 230, 89, 25));
        clsbtn->setStyleSheet(QString::fromUtf8("font: 12pt \"\351\273\221\344\275\223\";\n"
"background-color: rgba(255, 255, 255, 120);\n"
"border-radius:10px;\n"
""));
        label_2 = new QLabel(FindFri);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(100, 120, 21, 31));
        QFont font2;
        font2.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font2.setPointSize(12);
        font2.setBold(false);
        font2.setItalic(false);
        font2.setWeight(50);
        label_2->setFont(font2);
        label_2->setStyleSheet(QString::fromUtf8("font: 12pt \"\351\273\221\344\275\223\";\n"
"background-color: rgba(255, 255, 255,0);\n"
""));

        retranslateUi(FindFri);

        QMetaObject::connectSlotsByName(FindFri);
    } // setupUi

    void retranslateUi(QDialog *FindFri)
    {
        FindFri->setWindowTitle(QCoreApplication::translate("FindFri", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("FindFri", "Search", nullptr));
        cfmbtn->setText(QCoreApplication::translate("FindFri", "\347\241\256\350\256\244", nullptr));
        clsbtn->setText(QCoreApplication::translate("FindFri", "\345\205\263\351\227\255", nullptr));
        label_2->setText(QCoreApplication::translate("FindFri", "ID", nullptr));
    } // retranslateUi

};

namespace Ui {
    class FindFri: public Ui_FindFri {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FINDFRI_H
