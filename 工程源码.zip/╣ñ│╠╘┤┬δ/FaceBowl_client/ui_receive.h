/********************************************************************************
** Form generated from reading UI file 'receive.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RECEIVE_H
#define UI_RECEIVE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_receive
{
public:
    QLabel *label;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QWidget *widget;

    void setupUi(QDialog *receive)
    {
        if (receive->objectName().isEmpty())
            receive->setObjectName(QString::fromUtf8("receive"));
        receive->resize(331, 138);
        receive->setStyleSheet(QString::fromUtf8(""));
        label = new QLabel(receive);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(110, 20, 121, 41));
        QFont font;
        font.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        label->setFont(font);
        pushButton = new QPushButton(receive);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(40, 80, 93, 28));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font1.setPointSize(12);
        pushButton->setFont(font1);
        pushButton->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background-color: rgba(233, 239, 255,100);\n"
"border-radius:4px;\n"
"}\n"
"QpushButton:pressed\n"
"{\n"
"background-color: rgba(255, 255, 255, 50);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"\n"
""));
        pushButton_2 = new QPushButton(receive);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(180, 80, 93, 28));
        pushButton_2->setFont(font1);
        pushButton_2->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background-color: rgba(233, 239, 255,100);\n"
"border-radius:4px;\n"
"}\n"
"QpushButton:pressed\n"
"{\n"
"background-color: rgba(255, 255, 255, 50);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"\n"
""));
        widget = new QWidget(receive);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(0, 0, 331, 141));
        widget->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0.489, y2:1, stop:0 rgba(0, 239, 255, 170), stop:1 rgba(255, 255, 255, 255));\n"
"background-color: qlineargradient(spread:pad, x1:1, y1:0, x2:0.42, y2:1, stop:0 rgba(94, 173, 255, 184), stop:1 rgba(255, 255, 255, 255));"));
        widget->raise();
        label->raise();
        pushButton->raise();
        pushButton_2->raise();

        retranslateUi(receive);

        QMetaObject::connectSlotsByName(receive);
    } // setupUi

    void retranslateUi(QDialog *receive)
    {
        receive->setWindowTitle(QCoreApplication::translate("receive", "\346\216\245\346\224\266\346\226\207\344\273\266", nullptr));
        label->setText(QCoreApplication::translate("receive", "...\350\257\267\346\261\202\344\274\240\350\276\223\346\226\207\344\273\266", nullptr));
        pushButton->setText(QCoreApplication::translate("receive", "\346\216\245\346\224\266", nullptr));
        pushButton_2->setText(QCoreApplication::translate("receive", "\346\213\222\347\273\235", nullptr));
    } // retranslateUi

};

namespace Ui {
    class receive: public Ui_receive {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RECEIVE_H
