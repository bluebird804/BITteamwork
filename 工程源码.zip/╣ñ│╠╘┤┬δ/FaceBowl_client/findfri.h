#ifndef FINDFRI_H
#define FINDFRI_H

#include <QDialog>

namespace Ui {
class FindFri;
}

class FindFri : public QDialog
{
    Q_OBJECT

public:
    explicit FindFri(QWidget *parent = nullptr);
    ~FindFri();

private slots:
    void on_clsbtn_clicked();

    void on_cfmbtn_clicked();

private:
    Ui::FindFri *ui;
};

#endif // FINDFRI_H
