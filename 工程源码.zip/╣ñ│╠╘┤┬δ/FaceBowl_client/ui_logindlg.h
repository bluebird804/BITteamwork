/********************************************************************************
** Form generated from reading UI file 'logindlg.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINDLG_H
#define UI_LOGINDLG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QPushButton *loginbtn;
    QPushButton *closebtn;
    QPushButton *sinupbtn;
    QWidget *widget;
    QWidget *widget_2;
    QLabel *password;
    QLineEdit *pswdedit;
    QLabel *username;
    QLineEdit *usnmedit;
    QCheckBox *checkBox;
    QFrame *frame;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QStringLiteral("Dialog"));
        Dialog->resize(431, 370);
        Dialog->setStyleSheet(QStringLiteral(""));
        loginbtn = new QPushButton(Dialog);
        loginbtn->setObjectName(QStringLiteral("loginbtn"));
        loginbtn->setGeometry(QRect(38, 300, 91, 31));
        loginbtn->setStyleSheet(QString::fromUtf8("font: 12pt \"\351\273\221\344\275\223\";\n"
"background-color: rgba(255, 255, 255, 120);\n"
"border-radius:10px;\n"
""));
        closebtn = new QPushButton(Dialog);
        closebtn->setObjectName(QStringLiteral("closebtn"));
        closebtn->setGeometry(QRect(300, 300, 91, 31));
        closebtn->setStyleSheet(QString::fromUtf8("font: 12pt \"\351\273\221\344\275\223\";\n"
"background-color: rgba(255, 255, 255, 120);\n"
"border-radius:10px;\n"
""));
        sinupbtn = new QPushButton(Dialog);
        sinupbtn->setObjectName(QStringLiteral("sinupbtn"));
        sinupbtn->setEnabled(true);
        sinupbtn->setGeometry(QRect(170, 300, 91, 31));
        sinupbtn->setStyleSheet(QString::fromUtf8("font: 12pt \"\351\273\221\344\275\223\";\n"
"background-color: rgba(255, 255, 255, 120);\n"
"border-radius:10px;\n"
""));
        widget = new QWidget(Dialog);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(0, -21, 431, 181));
        widget->setStyleSheet(QStringLiteral("border-image: url(:/new/prefix1/back.gif);"));
        widget_2 = new QWidget(Dialog);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        widget_2->setGeometry(QRect(0, 159, 431, 211));
        widget_2->setStyleSheet(QStringLiteral("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(0, 69, 170, 56), stop:1 rgba(255, 255, 255, 255));"));
        password = new QLabel(widget_2);
        password->setObjectName(QStringLiteral("password"));
        password->setGeometry(QRect(120, 80, 71, 25));
        password->setStyleSheet(QString::fromUtf8("background-color: rgba(255, 255, 255, 0);\n"
"font: 12pt \"\351\273\221\344\275\223\";"));
        pswdedit = new QLineEdit(widget_2);
        pswdedit->setObjectName(QStringLiteral("pswdedit"));
        pswdedit->setGeometry(QRect(190, 80, 141, 25));
        pswdedit->setStyleSheet(QString::fromUtf8("font: 9pt \"\351\273\221\344\275\223\";\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;"));
        pswdedit->setEchoMode(QLineEdit::Password);
        username = new QLabel(widget_2);
        username->setObjectName(QStringLiteral("username"));
        username->setGeometry(QRect(120, 30, 67, 25));
        username->setMinimumSize(QSize(67, 17));
        username->setStyleSheet(QString::fromUtf8("background-color: rgba(255, 255, 255, 0);\n"
"font: 12pt \"\351\273\221\344\275\223\";"));
        username->setLineWidth(1);
        usnmedit = new QLineEdit(widget_2);
        usnmedit->setObjectName(QStringLiteral("usnmedit"));
        usnmedit->setGeometry(QRect(190, 30, 141, 25));
        usnmedit->setStyleSheet(QString::fromUtf8("font: 9pt \"\351\273\221\344\275\223\";\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;"));
        checkBox = new QCheckBox(widget_2);
        checkBox->setObjectName(QStringLiteral("checkBox"));
        checkBox->setGeometry(QRect(330, 80, 131, 25));
        checkBox->setStyleSheet(QString::fromUtf8("font: 9pt \"\351\273\221\344\275\223\";\n"
"background-color: rgba(255, 255, 255, 0);\n"
"border-radius:5px;"));
        checkBox->setChecked(false);
        frame = new QFrame(widget_2);
        frame->setObjectName(QStringLiteral("frame"));
        frame->setGeometry(QRect(20, 30, 81, 81));
        frame->setStyleSheet(QLatin1String("image: url(:/new/prefix1/HeadImage.png);\n"
"background-color: rgba(255, 255, 255, 0);"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        widget_2->raise();
        loginbtn->raise();
        closebtn->raise();
        sinupbtn->raise();
        widget->raise();

        retranslateUi(Dialog);
        QObject::connect(closebtn, SIGNAL(clicked()), Dialog, SLOT(close()));

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QApplication::translate("Dialog", "\347\231\273\345\275\225", Q_NULLPTR));
        loginbtn->setText(QApplication::translate("Dialog", "\347\231\273\345\275\225", Q_NULLPTR));
        closebtn->setText(QApplication::translate("Dialog", "\345\205\263\351\227\255", Q_NULLPTR));
        sinupbtn->setText(QApplication::translate("Dialog", "\346\263\250\345\206\214", Q_NULLPTR));
        password->setText(QApplication::translate("Dialog", "\345\257\206\347\240\201", Q_NULLPTR));
        pswdedit->setPlaceholderText(QApplication::translate("Dialog", "\350\257\267\350\276\223\345\205\245\345\257\206\347\240\201", Q_NULLPTR));
        username->setText(QApplication::translate("Dialog", "\347\224\250\346\210\267\345\220\215", Q_NULLPTR));
        usnmedit->setPlaceholderText(QApplication::translate("Dialog", "\350\257\267\350\276\223\345\205\245\347\224\250\346\210\267\345\220\215", Q_NULLPTR));
        checkBox->setText(QApplication::translate("Dialog", "\346\230\276\347\244\272\345\257\206\347\240\201", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINDLG_H
