/********************************************************************************
** Form generated from reading UI file 'send.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SEND_H
#define UI_SEND_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_send
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QComboBox *comboBox;
    QWidget *widget;

    void setupUi(QDialog *send)
    {
        if (send->objectName().isEmpty())
            send->setObjectName(QString::fromUtf8("send"));
        send->resize(400, 300);
        pushButton = new QPushButton(send);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(290, 100, 61, 31));
        QFont font;
        font.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font.setPointSize(10);
        pushButton->setFont(font);
        pushButton->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background-color: rgba(233, 239, 255,200);\n"
"border-radius:4px;\n"
"}\n"
"QpushButton:pressed\n"
"{\n"
"background-color: rgba(255, 255, 255, 50);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"\n"
""));
        pushButton_2 = new QPushButton(send);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(190, 240, 93, 31));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font1.setPointSize(12);
        pushButton_2->setFont(font1);
        pushButton_2->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background-color: rgba(233, 239, 255,200);\n"
"border-radius:4px;\n"
"}\n"
"QpushButton:pressed\n"
"{\n"
"background-color: rgba(255, 255, 255, 50);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"\n"
""));
        comboBox = new QComboBox(send);
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(100, 140, 251, 31));
        comboBox->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;\n"
"\n"
"\n"
"\n"
""));
        widget = new QWidget(send);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(0, 0, 401, 301));
        widget->setStyleSheet(QString::fromUtf8("border-image: url(:/77777.png);"));
        widget->raise();
        pushButton->raise();
        pushButton_2->raise();
        comboBox->raise();

        retranslateUi(send);

        QMetaObject::connectSlotsByName(send);
    } // setupUi

    void retranslateUi(QDialog *send)
    {
        send->setWindowTitle(QCoreApplication::translate("send", "\345\217\221\351\200\201\346\226\207\344\273\266", nullptr));
        pushButton->setText(QCoreApplication::translate("send", "\346\265\217\350\247\210", nullptr));
        pushButton_2->setText(QCoreApplication::translate("send", "\345\217\221\351\200\201", nullptr));
    } // retranslateUi

};

namespace Ui {
    class send: public Ui_send {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SEND_H
