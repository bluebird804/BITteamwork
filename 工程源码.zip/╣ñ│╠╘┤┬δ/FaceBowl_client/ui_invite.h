/********************************************************************************
** Form generated from reading UI file 'invite.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INVITE_H
#define UI_INVITE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_Invite
{
public:
    QLabel *label;

    void setupUi(QDialog *Invite)
    {
        if (Invite->objectName().isEmpty())
            Invite->setObjectName(QString::fromUtf8("Invite"));
        Invite->resize(400, 300);
        label = new QLabel(Invite);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(100, 110, 211, 71));
        QFont font;
        font.setPointSize(20);
        label->setFont(font);

        retranslateUi(Invite);

        QMetaObject::connectSlotsByName(Invite);
    } // setupUi

    void retranslateUi(QDialog *Invite)
    {
        Invite->setWindowTitle(QCoreApplication::translate("Invite", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("Invite", "\345\245\275\345\217\213\350\257\267\346\261\202\345\267\262\345\217\221\351\200\201", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Invite: public Ui_Invite {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INVITE_H
