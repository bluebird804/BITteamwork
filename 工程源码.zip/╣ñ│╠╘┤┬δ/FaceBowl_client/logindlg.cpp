#include "logindlg.h"
#include "signupdlg.h"
#include "ui_logindlg.h"
#include <QString>
#include <QMessageBox>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>
#include <QDebug>

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
    this->isconnected=false;
    setWindowIcon(QIcon(QStringLiteral(":/icon.png")));
    cnctsvr();
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_loginbtn_clicked()
{
    send();
    qDebug()<<judge;
}

void Dialog::on_sinupbtn_clicked()
{
    signupdlg sign;
    disconnect();
    sign.exec();
    cnctsvr();
}

void Dialog::on_checkBox_stateChanged()
{
    if(ui->checkBox->checkState()!=0)
        ui->pswdedit->setEchoMode(QLineEdit::Normal);
    else
        ui->pswdedit->setEchoMode(QLineEdit::Password);
}

void Dialog::cnctsvr()
{
    socket=new QTcpSocket(this);
    socket->abort();
    socket->connectToHost("192.168.43.218",6666);
    connect(socket,SIGNAL(connected()),this,SLOT(connted()));
    connect(socket,SIGNAL(readyRead()),this,SLOT(read()));
}

void Dialog::connted()
{
    this->isconnected =true;
   // QMessageBox::information(NULL, "连接成功", "登录连接成功！！！", QMessageBox::Yes);
}

void Dialog::read()
{
    QString data = socket->readAll();
    qDebug()<<data;
    if(data=="1")
    {
        judge=true;
    }
    else judge=false;
    if(judge)
    {
        accept();
    }
    else
    {
        QMessageBox::warning(this,tr("Warning"),tr("user name or password error!"),QMessageBox::Yes);
        ui->usnmedit->clear();
        ui->pswdedit->clear();
        ui->usnmedit->setFocus();
    }
}

void Dialog::send()
{
    if(this->isconnected)
        {
            QString name = ui->usnmedit->text(); //从单行文本框获得要发送消息
            QString password=ui->pswdedit->text();
            if(!name.isEmpty())
            {
                //发送消息到服务器
                this->socket->write("1");
                this->socket->write(name.toLatin1());
                this->socket->write(",");
                this->socket->write(password.toLatin1());
               // QMessageBox::information(NULL, "发送", "发送成功！！！", QMessageBox::Yes);
                //本地显示发送的消息
                /*QString localDispalyMessage = tr("send to server: ") + sendMessage \
                                                + QDateTime::currentDateTime().toString(" yyyy-M-dd hh:mm:ss") + tr("\n");
                ui->textBrowser->append(localDispalyMessage);*/
            }
            //else
                //QMessageBox::warning(this,"错误","消息不能为空!",QMessageBox::Ok);
        }
        else
            QMessageBox::warning(this,"错误","未连接到服务器!",QMessageBox::Ok);

}

void Dialog::disconnect()
{
    if(socket != nullptr)
    {
       // QMessageBox::warning(this,"错误","断开登录连接!",QMessageBox::Ok);
        socket->close(); //关闭客户端
        socket->deleteLater();
    }
}
