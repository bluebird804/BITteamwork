/********************************************************************************
** Form generated from reading UI file 'friendadded.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FRIENDADDED_H
#define UI_FRIENDADDED_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_friendadded
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLabel *label;

    void setupUi(QDialog *friendadded)
    {
        if (friendadded->objectName().isEmpty())
            friendadded->setObjectName(QString::fromUtf8("friendadded"));
        friendadded->resize(342, 140);
        friendadded->setStyleSheet(QString::fromUtf8("QDialog{background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(0, 69, 170, 56), stop:1 rgba(255, 255, 255, 255));}"));
        pushButton = new QPushButton(friendadded);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(40, 100, 93, 28));
        QFont font;
        font.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font.setPointSize(12);
        pushButton->setFont(font);
        pushButton->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background-color: rgba(233, 239, 255,200);\n"
"border-radius:4px;\n"
"}\n"
"QpushButton:pressed\n"
"{\n"
"background-color: rgba(255, 255, 255, 50);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"\n"
""));
        pushButton_2 = new QPushButton(friendadded);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(200, 100, 93, 28));
        pushButton_2->setFont(font);
        pushButton_2->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"background-color: rgba(255, 255, 255, 160);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background-color: rgba(233, 239, 255,200);\n"
"border-radius:4px;\n"
"}\n"
"QpushButton:pressed\n"
"{\n"
"background-color: rgba(255, 255, 255, 50);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"\n"
""));
        label = new QLabel(friendadded);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(110, 40, 191, 31));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font1.setPointSize(10);
        label->setFont(font1);

        retranslateUi(friendadded);

        QMetaObject::connectSlotsByName(friendadded);
    } // setupUi

    void retranslateUi(QDialog *friendadded)
    {
        friendadded->setWindowTitle(QCoreApplication::translate("friendadded", "\346\267\273\345\212\240\345\245\275\345\217\213\350\257\267\346\261\202", nullptr));
        pushButton->setText(QCoreApplication::translate("friendadded", "\345\220\214\346\204\217", nullptr));
        pushButton_2->setText(QCoreApplication::translate("friendadded", "\346\213\222\347\273\235", nullptr));
        label->setText(QCoreApplication::translate("friendadded", "...\350\257\267\346\261\202\346\267\273\345\212\240\346\202\250\344\270\272\345\245\275\345\217\213", nullptr));
    } // retranslateUi

};

namespace Ui {
    class friendadded: public Ui_friendadded {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FRIENDADDED_H
